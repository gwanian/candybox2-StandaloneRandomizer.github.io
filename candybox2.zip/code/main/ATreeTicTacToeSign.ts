enum ATreeTicTacToeSign{
    NO_SIGN,
    X,
    O
}