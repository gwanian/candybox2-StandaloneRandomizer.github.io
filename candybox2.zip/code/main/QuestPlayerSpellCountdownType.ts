enum QuestPlayerSpellCountdownType{
    SPELLS,
    POTIONS,
    ITEM_CAPACITIES,
    BLACKHOLE
}