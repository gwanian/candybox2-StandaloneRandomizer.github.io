enum QuestEntityDamageReasonWhatType{
    WEAPON,
    SPELL
}