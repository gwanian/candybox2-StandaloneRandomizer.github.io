///<reference path="./../../libs/jquery.d.ts"/>

class RenderLink{
    // Constructor
    constructor(){
        
    }
    
    // Public methods
    public run(): void{

    }
}