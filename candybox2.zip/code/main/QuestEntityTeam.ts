enum QuestEntityTeam{
    PLAYER,
    MOBS,
    NATURE
}