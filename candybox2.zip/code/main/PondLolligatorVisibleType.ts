enum PondLolligatorVisibleType{
    NOT_FULLY_VISIBLE_YET,
    FULLY_VISIBLE,
    NOT_FULLY_VISIBLE_ANYMORE
}