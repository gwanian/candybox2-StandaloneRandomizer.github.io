///<reference path="EqItem.ts"/>

class BootsOfIntrospection extends EqItem{
    // Constructor
    constructor(){
        super("eqItemBootsBootsOfIntrospection",
              "eqItemBootsBootsOfIntrospectionName",
              "eqItemBootsBootsOfIntrospectionDescription",
              "eqItems/boots/bootsOfIntrospection");
    }
}