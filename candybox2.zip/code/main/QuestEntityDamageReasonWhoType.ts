enum QuestEntityDamageReasonWhoType{
    NATURE,
    ENTITY
}