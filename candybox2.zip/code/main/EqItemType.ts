enum EqItemType{
    WEAPON,
    HAT,
    BODYARMOUR,
    GLOVES,
    BOOTS
}