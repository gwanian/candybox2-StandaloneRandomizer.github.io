enum FireballTargetType{
    NO_TARGET,
    TARGET_ENTITY,
    TARGET_STICK_ON_ENTITY,
    TARGET_POSITION
}