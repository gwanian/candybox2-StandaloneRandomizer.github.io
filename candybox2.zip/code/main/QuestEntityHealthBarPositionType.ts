enum QuestEntityHealthBarPositionType{
    RELATIVE, // The position of the bar is relative to the entity
    FIXED, // The position of the bar is fixed in the quest
    FIXED_ON_PAGE // The position of the bar is fixd in the quest and not affected by scrolling
}